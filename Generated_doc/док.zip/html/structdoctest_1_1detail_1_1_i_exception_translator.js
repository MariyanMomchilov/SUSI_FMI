var structdoctest_1_1detail_1_1_i_exception_translator =
[
    [ "IExceptionTranslator", "structdoctest_1_1detail_1_1_i_exception_translator.html#a3818157edf68f08110c7212ee87ff61e", null ],
    [ "~IExceptionTranslator", "structdoctest_1_1detail_1_1_i_exception_translator.html#a9031aa45964213709841eba4b3e19d48", null ],
    [ "translate", "structdoctest_1_1detail_1_1_i_exception_translator.html#a9c56005e4c83c13b859cc2e31102bfbc", null ]
];