var namespacedoctest =
[
    [ "detail", "namespacedoctest_1_1detail.html", "namespacedoctest_1_1detail" ],
    [ "Approx", "classdoctest_1_1_approx.html", "classdoctest_1_1_approx" ],
    [ "AssertData", "structdoctest_1_1_assert_data.html", "structdoctest_1_1_assert_data" ],
    [ "Context", "classdoctest_1_1_context.html", "classdoctest_1_1_context" ],
    [ "ContextOptions", "structdoctest_1_1_context_options.html", "structdoctest_1_1_context_options" ],
    [ "CurrentTestCaseStats", "structdoctest_1_1_current_test_case_stats.html", "structdoctest_1_1_current_test_case_stats" ],
    [ "IContextScope", "structdoctest_1_1_i_context_scope.html", "structdoctest_1_1_i_context_scope" ],
    [ "IReporter", "structdoctest_1_1_i_reporter.html", "structdoctest_1_1_i_reporter" ],
    [ "MessageData", "structdoctest_1_1_message_data.html", "structdoctest_1_1_message_data" ],
    [ "QueryData", "structdoctest_1_1_query_data.html", "structdoctest_1_1_query_data" ],
    [ "String", "classdoctest_1_1_string.html", "classdoctest_1_1_string" ],
    [ "StringMaker", "structdoctest_1_1_string_maker.html", null ],
    [ "StringMaker< R C::* >", "structdoctest_1_1_string_maker_3_01_r_01_c_1_1_5_01_4.html", null ],
    [ "StringMaker< T * >", "structdoctest_1_1_string_maker_3_01_t_01_5_01_4.html", null ],
    [ "SubcaseSignature", "structdoctest_1_1_subcase_signature.html", "structdoctest_1_1_subcase_signature" ],
    [ "TestCaseData", "structdoctest_1_1_test_case_data.html", "structdoctest_1_1_test_case_data" ],
    [ "TestCaseException", "structdoctest_1_1_test_case_exception.html", "structdoctest_1_1_test_case_exception" ],
    [ "TestRunStats", "structdoctest_1_1_test_run_stats.html", "structdoctest_1_1_test_run_stats" ]
];