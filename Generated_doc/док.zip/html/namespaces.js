var namespaces =
[
    [ "doctest", "namespacedoctest.html", "namespacedoctest" ],
    [ "doctest_detail_test_suite_ns", "namespacedoctest__detail__test__suite__ns.html", null ]
];