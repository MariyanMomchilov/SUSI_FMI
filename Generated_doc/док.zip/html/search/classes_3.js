var searchData=
[
  ['student',['Student',['../class_student.html',1,'']]],
  ['susi',['Susi',['../class_susi.html',1,'']]]
];
