var searchData=
[
  ['lname',['lName',['../class_uni_member.html#a8a67cfc2e07415052346918f915aeca6',1,'UniMember']]]
];
