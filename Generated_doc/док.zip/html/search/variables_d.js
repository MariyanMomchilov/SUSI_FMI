var searchData=
[
  ['rand_5fseed',['rand_seed',['../structdoctest_1_1_context_options.html#ab312bdc6f3c16646f04f75742f87ce0a',1,'doctest::ContextOptions']]],
  ['run_5fstats',['run_stats',['../structdoctest_1_1_query_data.html#a435f443f389323f47cb8b0e4202bbea9',1,'doctest::QueryData']]]
];
