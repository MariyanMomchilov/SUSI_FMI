var searchData=
[
  ['type',['type',['../class_discipline.html#aef1d2d599f850961fb622cc726a79dca',1,'Discipline::type()'],['../class_program.html#ae12d3f37585c3771e4b50832ff0d5b4d',1,'Program::type()']]]
];
