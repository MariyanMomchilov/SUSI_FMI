var searchData=
[
  ['year',['year',['../class_student.html#aca42f18eeeadf5428cf30a3078a97389',1,'Student']]],
  ['yearstograduate',['yearsToGraduate',['../class_program.html#a95e24889e5a0ca589d21207b827cb05a',1,'Program']]]
];
