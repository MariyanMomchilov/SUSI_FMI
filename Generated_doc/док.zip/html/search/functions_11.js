var searchData=
[
  ['write',['write',['../class_commands.html#a20c079b35574ed9f13dd29cee68f25f9',1,'Commands::write()'],['../class_commands.html#a37e78449bc8e24b233494dfc29c2f534',1,'Commands::write(std::ostream &amp;is)']]]
];
