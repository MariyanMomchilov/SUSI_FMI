var searchData=
[
  ['disciplines',['disciplines',['../class_discipline_container.html#aa751d8be73af398d0f08514954b352ca',1,'DisciplineContainer::disciplines()'],['../class_program.html#aa093662c1b22262af898b454fb00d2e2',1,'Program::disciplines()'],['../class_student.html#a5fd8877a3768663196207a89c65f2e13',1,'Student::disciplines()']]]
];
