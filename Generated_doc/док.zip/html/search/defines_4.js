var searchData=
[
  ['given',['GIVEN',['../doctest_8h.html#a6e079cc73cfaebf22e5a7914b3834cf9',1,'doctest.h']]]
];
