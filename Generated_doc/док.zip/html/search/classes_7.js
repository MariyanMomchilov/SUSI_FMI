var searchData=
[
  ['messagebuilder',['MessageBuilder',['../structdoctest_1_1detail_1_1_message_builder.html',1,'doctest::detail']]],
  ['messagedata',['MessageData',['../structdoctest_1_1_message_data.html',1,'doctest']]]
];
