var searchData=
[
  ['value',['value',['../structdoctest_1_1detail_1_1deferred__false.html#abc8eec7a8439ab592f76068cb408d106',1,'doctest::detail::deferred_false::value()'],['../structdoctest_1_1detail_1_1has__insertion__operator__impl_1_1has__insertion__operator.html#a8e8e9abdead07386f3d1f16bbca64986',1,'doctest::detail::has_insertion_operator_impl::has_insertion_operator::value()']]],
  ['version',['version',['../structdoctest_1_1_context_options.html#a08931527a9e5e634e64a336e5493a7c1',1,'doctest::ContextOptions']]]
];
