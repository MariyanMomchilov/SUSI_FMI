var searchData=
[
  ['grades',['grades',['../class_student.html#af7d0bacc326744ef438109be5feaf20c',1,'Student']]],
  ['group',['group',['../class_student.html#aec0553c2fba76a0c74375af5c24f92da',1,'Student']]]
];
