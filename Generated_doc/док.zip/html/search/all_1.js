var searchData=
[
  ['adddisc',['addDisc',['../class_student.html#a3cffc2aef59a99f5c0441f1bc73b090f',1,'Student']]],
  ['adddiscipline',['addDiscipline',['../class_discipline_container.html#af7be4f1504b7f6dbc65ddf4af9799fcd',1,'DisciplineContainer::addDiscipline()'],['../class_program.html#a383a0511ac35359940d9916f176da268',1,'Program::addDiscipline()']]],
  ['addgrade',['addGrade',['../class_student.html#ab5a5f93a5d48e7904413de356eb89811',1,'Student::addGrade()'],['../class_susi.html#a733754f4b69ee279041fe94d2b67b310',1,'Susi::addGrade()']]],
  ['addprogram',['addProgram',['../class_program_container.html#a9328196abac3c41551714de458faa75a',1,'ProgramContainer']]],
  ['addtodiscontainer',['addToDisContainer',['../class_susi.html#a75d9497bae2d3c173ab21e684ad9704c',1,'Susi']]],
  ['addtoprogcontainer',['addToProgContainer',['../class_susi.html#ae0c687f02724b86c9925aff184a62387',1,'Susi']]],
  ['advance',['advance',['../class_susi.html#a6be5a7767b5c4d06459ef4a3542aaee6',1,'Susi']]]
];
