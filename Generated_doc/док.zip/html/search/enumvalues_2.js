var searchData=
[
  ['couldhavefailedanddid',['CouldHaveFailedAndDid',['../namespacedoctest_1_1_test_case_failure_reason.html#aecb2ca1f80416d60f0d6b96f65859d3caa038bc08a903185cf809dd05056d6a75',1,'doctest::TestCaseFailureReason']]],
  ['crash',['Crash',['../namespacedoctest_1_1_test_case_failure_reason.html#aecb2ca1f80416d60f0d6b96f65859d3ca362a350971c370e7bf89f1993aeb2eeb',1,'doctest::TestCaseFailureReason']]],
  ['cyan',['Cyan',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92aee19aacebbc04b150add359e94684c83',1,'doctest::Color']]]
];
