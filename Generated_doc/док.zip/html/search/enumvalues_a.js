var searchData=
[
  ['red',['Red',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a67beb0a8d937993ad8b8cf6a238271f9',1,'doctest::Color']]]
];
