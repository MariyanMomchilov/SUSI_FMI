var searchData=
[
  ['status',['status',['../class_student.html#a3f6f0d1198b3ffb8749b2f8e2b5a18c1',1,'Student']]],
  ['susi_5fdisciplines',['susi_disciplines',['../class_susi.html#a565e54b3a964048eeeb0fc08db29a483',1,'Susi']]],
  ['susi_5fprograms',['susi_programs',['../class_susi.html#ae443169a57ca8f5a02cedbd857160cc4',1,'Susi']]],
  ['susi_5fstudents',['susi_students',['../class_susi.html#a01120305c1d7fac67fc79a026d9579ba',1,'Susi']]],
  ['system',['system',['../class_commands.html#a70ae07baccbd18977008ae6f17c6c32c',1,'Commands']]]
];
