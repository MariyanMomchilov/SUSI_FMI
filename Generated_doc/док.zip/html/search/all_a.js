var searchData=
[
  ['name',['name',['../class_discipline.html#aafa65128240ca298b7946e1c308c0d89',1,'Discipline::name()'],['../class_program.html#a8644dcfc3d08b475b5fe5ec359f05470',1,'Program::name()']]]
];
