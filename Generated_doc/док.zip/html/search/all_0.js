var searchData=
[
  ['_5fopen',['_open',['../class_commands.html#a97f3494ce4d8e6a68ca2746b60decc37',1,'Commands']]],
  ['_5fstudentindex',['_studentIndex',['../class_susi.html#a2c1e25d57c4cf29149803a4d86c8e585',1,'Susi']]]
];
