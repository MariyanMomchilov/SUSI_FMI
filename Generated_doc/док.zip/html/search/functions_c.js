var searchData=
[
  ['unimember',['UniMember',['../class_uni_member.html#a421f3bbcb1c24efda7d9db2817115c11',1,'UniMember::UniMember()'],['../class_uni_member.html#acb2e9cc54f0e8460d9db7f764966bbf3',1,'UniMember::UniMember(const std::string &amp;, const std::string &amp;, int)'],['../class_uni_member.html#a3a13cd99a8ccb8349350728bbb5db627',1,'UniMember::UniMember(const UniMember &amp;)']]]
];
