var searchData=
[
  ['cangraduate',['canGraduate',['../class_student.html#a082a64426f8133e4e176adb50ac0b477',1,'Student']]],
  ['canpass',['canPass',['../class_student.html#a84aa35d558891ea41302326b5879a3ae',1,'Student']]],
  ['change',['change',['../class_susi.html#a4b7d060513f731cd277bd4c5ae6b63de',1,'Susi::change(int fn, const std::string &amp;option, const std::string &amp;value)'],['../class_susi.html#a1c63140f45aed3553615f5da680e4edd',1,'Susi::change(int fn, const std::string &amp;option, size_t value)']]],
  ['commands',['Commands',['../class_commands.html#a5074950eaa028c7b44005a3c84870344',1,'Commands::Commands()=default'],['../class_commands.html#a50e97e2c1cc38b6b84252cac9af09f3d',1,'Commands::Commands(const std::string &amp;)=delete']]]
];
