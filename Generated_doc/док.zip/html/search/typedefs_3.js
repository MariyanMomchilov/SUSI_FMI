var searchData=
[
  ['ostream',['ostream',['../doctest_8h.html#a116af65cb5e924b33ad9d9ecd7a783f3',1,'doctest.h']]]
];
