var searchData=
[
  ['setfname',['setFname',['../class_uni_member.html#afe68f8430ad033de7f87960946e29038',1,'UniMember']]],
  ['setfnumber',['setFnumber',['../class_uni_member.html#ad979c7e5a0fe22e5928c8cc71964a8e2',1,'UniMember']]],
  ['setgroup',['setGroup',['../class_student.html#a144829ea7cbfa16de9bc079365388f13',1,'Student']]],
  ['setlname',['setLname',['../class_uni_member.html#a345f73ca3ae57f45643552ba1d01a02e',1,'UniMember']]],
  ['setprogram',['setProgram',['../class_student.html#a75ce18eab05c57afd31036ffa8cea201',1,'Student']]],
  ['setstatus',['setStatus',['../class_student.html#a2d6d1de16bb99c7678f2ef8004928d18',1,'Student']]],
  ['setyear',['setYear',['../class_student.html#ac068619857e22e8a208c47314322cd11',1,'Student']]],
  ['size',['size',['../class_discipline_container.html#a9ecb0f7eeed76342c004bbb4389353a5',1,'DisciplineContainer::size()'],['../class_program_container.html#a6dc1ecf361eb185c1149d1ee6ad01645',1,'ProgramContainer::size()']]],
  ['sort',['sort',['../class_susi.html#a98cf9bfd27148f4a3c108ff5dcc0dd25',1,'Susi']]],
  ['student',['Student',['../class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d',1,'Student::Student()'],['../class_student.html#a65d6b3a714d5c60e8c9ffbc6d64f1a69',1,'Student::Student(const std::string &amp;, const std::string &amp;, int, int, int, int)'],['../class_student.html#a5c162823e7c932ba957b58215ee969c1',1,'Student::Student(const std::string &amp;, const std::string &amp;, int, int, int, int, const Program &amp;)'],['../class_student.html#a4bc8fcbadabef3f7b81c40536f3713b1',1,'Student::Student(const Student &amp;)']]],
  ['susi',['Susi',['../class_susi.html#a787354112d858530b76a94845c47e99e',1,'Susi']]]
];
