var structdoctest_1_1_i_context_scope =
[
    [ "IContextScope", "structdoctest_1_1_i_context_scope.html#a067a2f9a9e53b010eb7b0a2ab88c76fd", null ],
    [ "~IContextScope", "structdoctest_1_1_i_context_scope.html#aa99357c233d6a040451628bc6a6c6c2e", null ],
    [ "stringify", "structdoctest_1_1_i_context_scope.html#affbf0f9bf8107a4a8a805d237288141d", null ]
];