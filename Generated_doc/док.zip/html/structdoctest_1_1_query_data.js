var structdoctest_1_1_query_data =
[
    [ "data", "structdoctest_1_1_query_data.html#a8085a29db9a1cd5c7eff22ef44e9a9e8", null ],
    [ "num_data", "structdoctest_1_1_query_data.html#af1033338fe975ae3c19b16452401230d", null ],
    [ "run_stats", "structdoctest_1_1_query_data.html#a435f443f389323f47cb8b0e4202bbea9", null ]
];