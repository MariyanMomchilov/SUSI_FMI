var structdoctest_1_1detail_1_1_test_suite =
[
    [ "operator*", "structdoctest_1_1detail_1_1_test_suite.html#a8fea9c73837193c3a5e2f0829aa5a9cd", null ],
    [ "operator*", "structdoctest_1_1detail_1_1_test_suite.html#a87a44a0d2e0c4955c64ef5d01f7115d8", null ],
    [ "m_description", "structdoctest_1_1detail_1_1_test_suite.html#a0458cf84f4f2d308162b26c95a1bbbce", null ],
    [ "m_expected_failures", "structdoctest_1_1detail_1_1_test_suite.html#ab0167ce62046912d83780302cb86adca", null ],
    [ "m_may_fail", "structdoctest_1_1detail_1_1_test_suite.html#aeaf438e6731c002c2447e8e87c46c82b", null ],
    [ "m_should_fail", "structdoctest_1_1detail_1_1_test_suite.html#a3c5953ed157cfc68dfc37cce66fb4103", null ],
    [ "m_skip", "structdoctest_1_1detail_1_1_test_suite.html#a82ecf10ca3db6bff60a087378267caea", null ],
    [ "m_test_suite", "structdoctest_1_1detail_1_1_test_suite.html#ab6260436f6fd52d473c0020ff916753c", null ],
    [ "m_timeout", "structdoctest_1_1detail_1_1_test_suite.html#a430d6e400dd91b9a21c7bb06ede81ec9", null ]
];