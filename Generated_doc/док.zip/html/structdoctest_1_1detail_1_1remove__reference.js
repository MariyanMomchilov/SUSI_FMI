var structdoctest_1_1detail_1_1remove__reference =
[
    [ "type", "structdoctest_1_1detail_1_1remove__reference.html#ab3cba0e8bc4c71b7f4ecdf85476ec4cc", null ]
];