var structdoctest_1_1detail_1_1remove__reference_3_01_t_01_6_01_4 =
[
    [ "type", "structdoctest_1_1detail_1_1remove__reference_3_01_t_01_6_01_4.html#a37201537c0190f14f504d9f507bc042a", null ]
];