var classdoctest_1_1detail_1_1_context_scope =
[
    [ "ContextScope", "classdoctest_1_1detail_1_1_context_scope.html#a344c76a0374615d567a084c0a0ffd215", null ],
    [ "ContextScope", "classdoctest_1_1detail_1_1_context_scope.html#afca3228fdeb0e86257a21f826c4247ff", null ],
    [ "~ContextScope", "classdoctest_1_1detail_1_1_context_scope.html#a1ee7d4702398ee8d0e80ab843aa260d7", null ],
    [ "stringify", "classdoctest_1_1detail_1_1_context_scope.html#a4636ac32ae41ae108c7ada4a164ffaeb", null ]
];