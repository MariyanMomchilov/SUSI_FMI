var namespacedoctest_1_1detail_1_1has__insertion__operator__impl =
[
    [ "any_t", "structdoctest_1_1detail_1_1has__insertion__operator__impl_1_1any__t.html", "structdoctest_1_1detail_1_1has__insertion__operator__impl_1_1any__t" ],
    [ "has_insertion_operator", "structdoctest_1_1detail_1_1has__insertion__operator__impl_1_1has__insertion__operator.html", null ]
];