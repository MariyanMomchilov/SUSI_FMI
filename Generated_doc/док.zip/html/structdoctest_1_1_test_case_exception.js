var structdoctest_1_1_test_case_exception =
[
    [ "error_string", "structdoctest_1_1_test_case_exception.html#a656c8971ccbedc7d3a0a38f7c6af927e", null ],
    [ "is_crash", "structdoctest_1_1_test_case_exception.html#af30d801dae6dd2f4ea01690bbf5faeca", null ]
];