var classdoctest_1_1detail_1_1_context_scope_base =
[
    [ "ContextScopeBase", "classdoctest_1_1detail_1_1_context_scope_base.html#af3a3ff7ad6b98142ef0f7e1d01912d48", null ],
    [ "destroy", "classdoctest_1_1detail_1_1_context_scope_base.html#a6f223de9a972b08bf1b9e9d2d99ab4c6", null ]
];