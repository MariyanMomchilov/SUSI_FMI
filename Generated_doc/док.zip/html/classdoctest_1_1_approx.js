var classdoctest_1_1_approx =
[
    [ "Approx", "classdoctest_1_1_approx.html#a86f0d1b44c1cf095697f23ccdab00802", null ],
    [ "epsilon", "classdoctest_1_1_approx.html#af8df6b0af00fd875e5b6a0c30b86f636", null ],
    [ "operator()", "classdoctest_1_1_approx.html#aae907c5ea1c4ac94e134db9e35da7dce", null ],
    [ "scale", "classdoctest_1_1_approx.html#a62185fd4c09a63dab61bd893574d8473", null ],
    [ "operator!=", "classdoctest_1_1_approx.html#a44d4bbc575291095c884848887538233", null ],
    [ "operator!=", "classdoctest_1_1_approx.html#ae86972ba14656f422afdcc60cd2cdb08", null ],
    [ "operator<", "classdoctest_1_1_approx.html#acf32148e34dc6444a3bb4b16e7298279", null ],
    [ "operator<", "classdoctest_1_1_approx.html#a54ce2536ed164b79688f43e373dcbf7b", null ],
    [ "operator<=", "classdoctest_1_1_approx.html#af2fef67cf4508a446eeaf38dafae661f", null ],
    [ "operator<=", "classdoctest_1_1_approx.html#a7f32e572caa5ee152b8ade301fcfd838", null ],
    [ "operator==", "classdoctest_1_1_approx.html#a2b6b56551f113fd12f4a52b4d3e5fd7e", null ],
    [ "operator==", "classdoctest_1_1_approx.html#a1b99d0c4c3924a253474e68ae30e1175", null ],
    [ "operator>", "classdoctest_1_1_approx.html#a97a6e92b9c9dacc0adb2f76f9faf2924", null ],
    [ "operator>", "classdoctest_1_1_approx.html#a12a93e1726180db4091cb2e3b8ba5e30", null ],
    [ "operator>=", "classdoctest_1_1_approx.html#acf882dbff26c57cd8404da3edd46f45e", null ],
    [ "operator>=", "classdoctest_1_1_approx.html#a52e1bcec19171f0ec55cc3a280188a03", null ],
    [ "toString", "classdoctest_1_1_approx.html#aa1ba324952b7844d35fc569b1c6c139a", null ]
];