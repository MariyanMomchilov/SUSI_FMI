var structdoctest_1_1detail_1_1_result =
[
    [ "Result", "structdoctest_1_1detail_1_1_result.html#ae4d2e8633aedaffa31f5c8b8530f522c", null ],
    [ "m_decomp", "structdoctest_1_1detail_1_1_result.html#a97968e037266580a799ab3deb9365b79", null ],
    [ "m_passed", "structdoctest_1_1detail_1_1_result.html#a03ff571186856a429ada967ddfdf3006", null ]
];