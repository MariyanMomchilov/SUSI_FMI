var annotated_dup =
[
    [ "Commands", "class_commands.html", "class_commands" ],
    [ "Discipline", "class_discipline.html", "class_discipline" ],
    [ "DisciplineContainer", "class_discipline_container.html", "class_discipline_container" ],
    [ "Program", "class_program.html", "class_program" ],
    [ "ProgramContainer", "class_program_container.html", "class_program_container" ],
    [ "Student", "class_student.html", "class_student" ],
    [ "Susi", "class_susi.html", "class_susi" ],
    [ "UniMember", "class_uni_member.html", "class_uni_member" ]
];